import subprocess
# required
# pip install gdown
# Download the gdrive file with link
subprocess.run(["gdown", "https://drive.google.com/uc?id=1jQSrxM4rBwVe2M9GFpShwH9NiER7l7Ol"])


