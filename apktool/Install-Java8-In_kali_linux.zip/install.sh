installjava()
{
  # Check if Java 8 is installed
  if java -version 2>&1 | grep -q '1.8'; then
    echo "Java 8 is already installed. Exiting script."
    return
  fi

  # Proceed with installation if Java 8 is not found
  pip install gdown
  python3 downloadjava.py

  sudo tar -xf jdk-8u381-linux-x64.tar.gz -C /opt/
  sudo update-alternatives --install "/usr/bin/java" "java" "/opt/jdk1.8.0_381/bin/java" 1
  sudo update-alternatives --config java

  clear
  echo 'Done'
  java -version
}

installjava
